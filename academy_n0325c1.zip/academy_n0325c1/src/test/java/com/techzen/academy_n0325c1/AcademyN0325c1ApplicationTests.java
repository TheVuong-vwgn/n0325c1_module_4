package com.techzen.academy_n0325c1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademyN0325c1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
