package com.techzen.academy_n0325c1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademyN0325c1Application {

	public static void main(String[] args) {
		SpringApplication.run(AcademyN0325c1Application.class, args);
	}

}
